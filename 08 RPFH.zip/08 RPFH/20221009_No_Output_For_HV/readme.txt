Problem:
  run cd /data/bin/redisClusterInstall /data/bin/redisClusterInstall/check-cluster-host-hv2.sh
  No output  
  
Solution for this time:
  - run cd /data/bin/redisClusterInstall
  - run ./check-cluster-host-hv2.sh (Dont run whole path!)
  - Details please see 20221009_PROD_ISSUE.rtf

  