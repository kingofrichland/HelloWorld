Problem:
  [ERR] Sorry, can't connect to node 172.16.26.86:6381
  
Solution for this time:
  - follow ITOG
  - run /data/server/redis/bin/redis-server /data/server/redis/conf/6381.conf
  - then health check again
  - run cd /data/bin/redisClusterInstall
  - run ./check-cluster-host-hv2.sh
  - Details please see 20220911_PROD_ISSUE.rtf

  